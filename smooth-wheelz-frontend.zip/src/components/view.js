import React, { Component } from 'react';
import axios from "axios";

const ridesURL = "http://localhost:2500/rent/";

class View extends Component {
    constructor(props) {
        super(props);
        this.state = {
            customerId: "",
            selectedRides: [],
            errorMessage: ""
        }
    }

    handleChange = (event) => {

        this.setState({ customerId: event.target.value });

    }

    fetchRides = (event) => {
        event.preventDefault();
        axios.get(ridesURL+this.state.customerId)
            .then(response => this.setState({ selectedRides: response.data, errorMessage: "" }))
            .catch(error => {
                if (error.response) {
                    this.setState({ errorMessage: error.response.data.message, successMessage: "" });
                } else {
                    this.setState({ errorMessage: "server error", successMessage: "" });
                }
            })
    }

    displayRides = () => {
        let rowArray = [];
        let months=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
        let days=['Sun','Mon','Tues','Wed','Thurs','Fri','Sat'];
        let date=""
        for (let i = 0; i < this.state.selectedRides.length; i++) {
            date=""
            let vehicleType = null;
            if (this.state.selectedRides[i].vehicleType === "2Wheeler") {
                vehicleType = "Two Wheeler"
            } else {
                vehicleType = "Four Wheeler"
            }
            let d=new Date(this.state.selectedRides[i].rentDate);
            date=days[d.getDay()]+" "+months[d.getMonth()]+" "+d.getDate()+" "+d.getFullYear();
            rowArray.push(
                <tr key={i}>
                    <td>
                        {vehicleType}
                    </td>
                    <td>
                        {date}
                    </td>
                    <td>
                        {this.state.selectedRides[i].duration} Hours
                    </td>
                    <td>
                        Rs. {this.state.selectedRides[i].rentAmount}
                    </td>
                </tr>
            )
        }
        return rowArray;
    }

    render() {
        return (
            <div> <br />
                <div className="row">
                    <div className="col-md-6 offset-3">
                        <div className="card">
                            <div className="card-header text-light bg-dark">
                                <h4 className="text-center">Ride Details</h4>
                            </div>
                            <div className="card-body text-light bg-dark">
                                {this.state.selectedRides.length == 0 ? (<form >
                                    <div className="form-group">
                                        <label htmlFor="customerId">customerId </label>
                                        <input
                                            type="number"
                                            name="customerId"
                                            id="customerId"
                                            placeholder="Enter valid customer id"
                                            onChange={this.handleChange}
                                            className="form-control"
                                        />

                                        {/* <span name="customerIdError" className="text-danger">
                                            {this.state.errorMessage}
                                        </span> */}
                                    </div>
                                    <button type="submit" className="btn btn-primary" name="showRides" 
                                        disabled={this.state.customerId.length > 0 ? false : true} onClick={(event)=>this.fetchRides(event)}
                                    >Show Rides</button>

                                </form>) : (<div><table className="table table-dark table-striped">
                                    <thead>
                                        <tr>
                                            <th>Vehicle Type</th>
                                            <th>Rent Date</th>
                                            <th>Duration</th>
                                            <th>Rent Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {this.displayRides()}
                                    </tbody>

                                </table>
                            <button type="submit" className="btn btn-danger" name="close"
                            onClick={()=>this.setState({selectedRides: []})}
                       >Close</button>
                       </div>
                        )}
                        <br/>
                        <span name="errorMessage" className="text-danger text-bold">
                                    {this.state.errorMessage}
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default View;