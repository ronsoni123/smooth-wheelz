import React, { Component } from 'react'
import axios from "axios";

const rentURL = "http://localhost:2500/rent/";

class Rent extends Component {
    constructor() {
        super();
        this.state = {
            rentForm: {
                customerId: "",
                rentDate: "",
                duration: "",
                vehicleType: ""
            },
            formErrorMessage: {
                customerId: "",
                rentDate: "",
                duration: "",
                vehicleType: ""
            },
            formValid: {
                customerId: false,
                rentDate: false,
                duration: false,
                vehicleType: false,
                buttonActive: false
            },
            successMessage: "",
            errorMessage: ""
        }
    }

    handleChange = (event) => {
        var rentForm = this.state.rentForm;
        if (event.target.name === "customerId") {
            rentForm.customerId = event.target.value
        } else if (event.target.name === "vehicleType") {
            rentForm.vehicleType = event.target.value
        } else if (event.target.name === "rentDate") {
            rentForm.rentDate = event.target.value
        } else {
            rentForm.duration = event.target.value
        }
        this.setState({ rentForm: rentForm });
        this.validateField(event.target.name, event.target.value);
    }

    validateField = (fieldName, value) => {
        let formErrorMessage = this.state.formErrorMessage;
        let formValid = this.state.formValid;
        switch (fieldName) {
            case "customerId":
                if (value === "") {
                    formErrorMessage.customerId = "field required";
                    formValid.customerId = false;
                } else if (!value.match(/^[6][0-9]{5}$/)) {
                    formErrorMessage.customerId = "Customer Id should start with 6 and should be a 6 digit number";
                    formValid.customerId = false;
                } else {
                    formErrorMessage.customerId = "";
                    formValid.customerId = true;
                }
                break;
            case "rentDate":
                let cDate=new Date();
                let rentDate=new Date(value)
                if (value === "") {
                    formErrorMessage.rentDate = "field required";
                    formValid.rentDate = false;
                } else if (rentDate<cDate && rentDate.getDate()!=cDate.getDate()) {
                    formErrorMessage.rentDate = "Rent date cannot be before current date";
                    formValid.rentDate = false;
                } else {
                    formErrorMessage.rentDate = "";
                    formValid.rentDate = true;
                }
                break;
            case "duration":
                if (value === "") {
                    formErrorMessage.duration = "field required";
                    formValid.duration = false;
                }else if (value<=0) {
                    formErrorMessage.duration = "Duration of rent cannot be less than 1 Hour";
                    formValid.duration = false;
                } else {
                    formErrorMessage.duration = "";
                    formValid.duration = true;
                    formValid.vehicleType = true;
                }
                break;
            default:
                break;
        }
        // console.log(this.state.rentForm)
        formValid.buttonActive =
            formValid.rentDate &&
            formValid.customerId &&
            formValid.duration&&
            formValid.vehicleType
        this.setState({ formErrorMessage:formErrorMessage , formValid: formValid, successMessage: "" })
    }

    rentVehicle = (event) => {
        event.preventDefault();
        axios.put(rentURL+this.state.rentForm.customerId,this.state.rentForm).then((response)=>{
            this.setState({ successMessage: response.data.message, errorMessage: "" });
        }).catch(error => {
            if (error.response) {
                this.setState({ errorMessage: error.response.data.message, successMessage: "" });
              } else {
                this.setState({ errorMessage: "server error", successMessage: "" });
              }
          });
    }

    render() {
        return (
            <div className="Rent"><br />
                <div className="row">
                    <div className="col-md-4 offset-4">
                        <div className="card bg-dark text-light">
                            <div className="card-header">
                                <h4>Vehicle Rental Form</h4>
                            </div>
                            <div className="card-body text-left">
                                <form className="Rent" onSubmit={this.rentVehicle}>
                                    <div className="form-group">
                                        <label htmlFor="customerId">customerId </label>
                                        <input
                                            type="number"
                                            name="customerId"
                                            id="customerId"
                                            placeholder="Enter valid customer id"
                                            // value={this.state.rentForm.customerId}
                                            onChange={this.handleChange}
                                            className="form-control"
                                        />

                                        <span name="customerIdError" className="text-danger">
                                            {this.state.formErrorMessage.customerId}
                                        </span>
                                    </div>

                                    <div className="form-group">
                                        <label class="form-check-label">
                                            Vehicle Type
                                        </label>&nbsp;
                                        <div className=" form-check-inline">
                                            <label class="form-check-label" htmlFor="2Wheeler">
                                                <input class="form-check-input" type="radio" name="vehicleType" id="2Wheeler" value="2Wheeler" onChange={this.handleChange} /> Two Wheeler
                                        </label>
                                        </div>
                                        <div className=" form-check-inline">
                                            <label class="form-check-label" htmlFor="4Wheeler">
                                                <input class="form-check-input" type="radio" name="vehicleType" id="4Wheeler" value="4Wheeler" onChange={this.handleChange} /> Four Wheeler
                                        </label>
                                        </div>
                                    </div>
                                    <div className="form-group">
                                        <label htmlFor="rentDate">Rent Date </label>
                                        <input
                                            type="date"
                                            name="rentDate"
                                            id="rentDate"
                                            placeholder="mm/dd/yyyy"
                                            value={this.state.rentForm.rentDate}
                                            onChange={this.handleChange}
                                            className="form-control"
                                        />

                                        <span name="rentDateError" className="text-danger">
                                            {this.state.formErrorMessage.rentDate}
                                        </span>
                                    </div>
                                    <div className="form-group">
                                        <label htmlFor="duration">Duration</label>
                                        <input
                                            type="number"
                                            name="duration"
                                            id="duration"
                                            placeholder="Enter the duration in hour"
                                            value={this.state.rentForm.duration}
                                            onChange={this.handleChange}
                                            className="form-control"
                                        />
                                        <span name="durationError" className="text-danger">
                                            {this.state.formErrorMessage.duration}
                                        </span>
                                    </div>
                                    <button type="submit" className="btn btn-primary" name="bookRide"
                                        disabled={!this.state.formValid.buttonActive}>Book Ride</button>
                                </form>
                                <br />
                                <span name="successMessage" className="text-success text-bold">
                                    {this.state.successMessage}
                                </span>
                                <span name="errorMessage" className="text-danger text-bold">
                                    {this.state.errorMessage}
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default Rent;