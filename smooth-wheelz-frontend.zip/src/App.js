import React, { Component } from 'react';
import { BrowserRouter as Router, Route, Switch, Link } from "react-router-dom";
import './App.css';
/* Import the required modules/dependencies here */

/* DO NOT REMOVE THE BELOW IMPORT STATEMENT */
import Evaluator from './components/evaluator';
import Rent from './components/rent';
import View from './components/view';

class App extends Component {
  render() {
    return (
      <Router>
        <div>
          { /* DO NOT REMOVE THIS COMPONENT TAG */}
          <Evaluator></Evaluator>
          <nav className="navbar navbar-expand-sm bg-dark navbar-dark">
            <div className="navbar-header">
              <a className="nav-item active navbar-brand" href="/">Smooth Wheelz</a>
            </div>
            <ul className="navbar-nav ml-auto">
              <li className="nav-item">
                <Link className="nav-link" to="/rent"> Rent a Vehicle </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/view"> View Ride Details </Link>
              </li>
            </ul>
          </nav>
          <Switch>
            <Route exact path="/rent" component={Rent} />
            <Route exact path="/view" component={View} />
            <Route exact path="*" component={Rent} />
          </Switch>
        </div>
      </Router>
    );
  }
}

export default App;