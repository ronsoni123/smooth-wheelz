
var Validator = {}

Validator.validateCustomer = (customerId) => {
    var custId = new String(customerId);
    var pattern = /^6[0-9]{5}$/;
    if (!custId.match(pattern)) {

        let err = new Error("Invalid! CustomerId must start with 6 and should be a 6 digit number");
        err.status = 406;
        throw err;
    }
}

Validator.validateDate = (rentDate) => {

    let rDate = new Date(rentDate).setUTCHours(0, 0, 0, 0);
    let today = new Date().setUTCHours(0, 0, 0, 0);
    if (today > rDate) {
        let err = new Error("Date of booking must be greater than today")
        err.status = 406;
        throw err;
    }
}


module.exports = Validator;

