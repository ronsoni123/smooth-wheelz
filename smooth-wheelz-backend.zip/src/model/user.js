var collection = require('../utilities/connections');
var rentalDb = {}

rentalDb.generateId = () => {
    return collection.getCollection().then(function (collection) {
        return collection.distinct("rent.rentId").then((rentId) => {
            var max_rent_Id = Math.max(...rentId);
            if (max_rent_Id > 0)
                return max_rent_Id + 1;
            else
                return 2001
        })

    })
}

rentalDb.customerDetails = (customerId) => {
    return collection.getCollection().then((collection) => {
        return collection.findOne({ customerId: customerId }).then((customerData) => {
          if(customerData) return customerData
          else return null
        })
    })
}

rentalDb.rentVehicle = (customerId, vehicleObj) => {

    return rentalDb.generateId().then((rentId) => {
        vehicleObj.rentId = rentId;
        return collection.getCollection().then((rental) => {
            return rental.updateOne({ customerId: customerId },
                {
                    $push: {
                        rent: vehicleObj
                    }
                }).then((saved) => {
                    if (saved.nModified == 1)
                        return vehicleObj
                    else
                        return null
                })
        })
    })
}


module.exports = rentalDb;
