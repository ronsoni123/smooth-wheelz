class Rental {
    constructor(obj){
        this.rentId = obj.rentId;
        this.vehicleType= obj.vehicleType;
        this.rentDate = obj.rentDate;
        this.duration = obj.duration;
        this.rentAmount = obj.rentAmount; 
    }
}

module.exports = Rental;