var today = new Date();
var year = today.getFullYear();
var month = today.getMonth();
var day = today.getDate();


collectionDocument = [
    {
        "customerId": 600001,
        "name": 'Dolly',
        "location": 'Mysore',
        "emailId": "dolly@infy.com",
        "rent": [{
            "rentId": 2001,
            "vehicleType": "2Wheeler",
            "rentDate": new Date(year, month + 2, day),
            "duration": 2,
            "rentAmount": 100
        }, {
            "rentId": 2003,
            "vehicleType": "4Wheeler",
            "rentDate": new Date(year, month + 2, day+3),
            "duration": 6,
            "rentAmount": 600
        }
        ]
    },
    {
        "customerId": 600002,
        "name": 'Annie',
        "location": 'Trivandrum',
        "emailId": "annie@infy.com",
        "rent": [{
            "rentId": 2002,
            "vehicleType": "2Wheeler",
            "rentDate": new Date(year, month + 1, day+5),
            "duration": 3,
            "rentAmount": 150
        }]
    },
    {
        "customerId": 600003,
        "name": 'Rithesh',
        "location": 'Bangalore',
        "emailId": "rithesh@infy.com",
        "rent": [{
            "rentId": 2004,
            "vehicleType": "4Wheeler",
            "rentDate": new Date(year, month + 1, day+7),
            "duration": 4,
            "rentAmount": 400
        }]
    },
    {
        "customerId": 600004,
        "name": 'Huifha',
        "location": 'Mandya',
        "emailId": "huifha@infy.com",
        "rent": [{
            "rentId": 2005,
            "vehicleType": "2Wheeler",
            "rentDate": new Date(year, month , day+3),
            "duration": 4,
            "rentAmount": 200
        }]
    }, {
        "customerId": 600005,
        "name": "Shresha",
        "location": "Utarkand",
        "emailId": "shresha@infy.com",
        "rent": []
    }
]


var collection = require('../utilities/connections');

exports.setupDb = () => {
    return collection.getCollection().then((myCollection) => {
        return myCollection.deleteMany().then((data) => {
            return myCollection.insertMany(collectionDocument).then((data) => {
                if (data) {
                    return "Insertion Successfull"
                } else {
                    throw new Error("Insertion failed")
                }
            })
        })

    })
}
