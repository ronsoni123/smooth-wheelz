var express = require('express');
var routing = express.Router();
var service = require('../service/user');
var Rental = require('../model/rental')
var parser = require("../parser").reportGenerator
const getSymbolFromCurrency = require('currency-symbol-map')
var allow = true;


routing.get('/evaluate', (req, res, next) => {
    console.log("Request came!!");
    service.evaluate()
        .then((data) => {
            console.log("Completed success!!");
            res.send(data)
        }).catch((err) => {
            console.log("Completed err!!");
            next(err)
        })
})

routing.put('/rent/:customerId', (req, res, next) => {
    var customerId = parseInt(req.params.customerId)
    var rentalObj = new Rental(req.body);
    service.rent(customerId, rentalObj).then((vehicle) => {
        res.status(200)
        res.json({ "message": "Your rent id is " + vehicle.rentId + ", amount to be paid " + getSymbolFromCurrency('INR') + vehicle.rentAmount })
    }).catch((err) => {
        next(err);
    })
})


routing.get('/rent/:customerId', function (req, res, next) {
    var customerId = parseInt(req.params.customerId)
    service.getRentals(customerId).then(function (rentedVehicle) {
        res.status(200)
        res.json(rentedVehicle)
    }).catch(function (err) {
        next(err)
    })
})

routing.get("/test", (req, res, next) => {
    if (allow) {
        allow = false;
        parser().then((data) => {
            console.log("Verification Completed", data)
            allow = true;
            res.send(data)
        }).catch((err) => {
            console.log(err.message);
            allow = true;
            next(err)
        })
    }
})




module.exports = routing;